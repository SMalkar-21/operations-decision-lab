# Operations Intelligence — Power BI Desktop build kit

## What this is
A reproducible **Power BI Desktop report-building kit** using **78,000 synthetic customer interactions** dated June 2025–August 2026. Includes source CSV, DAX measures, scenario table formula, theme, reconciliation data and visual layout references.

This is **not** a native `.pbix` or `.pbit` file: Power BI Desktop must be used to create, test and save the actual report. The PNGs are design references, **not screenshots from Power BI**. The existing interactive website remains HTML/JavaScript.

## Expected global KPI checks (all months, all teams and channels)
- Total Contacts: 78,000
- SLA %: 85.37%
- FCR %: 78.41%
- CSAT Positive %: 81.54% among surveyed contacts
- AHT: 8.45 minutes
- Billing / Email / Jan–Mar 2026: 1,827 contacts, 662 breaches, 63.77% SLA
- 25% hypothetical recovery: 166 avoided breaches (rounded), ~0.21 percentage-point global uplift

## Quick start
1. Open Microsoft Power BI Desktop (Windows).
2. Get data > Text/CSV > Contacts_SYNTHETIC_Jun2025_Aug2026.csv > Transform Data. Set contact_date=Date, counts/flags=Whole Number, workload_index/handle_minutes/csat_score=Decimal Number, other fields=Text.
3. Close & Apply. Name the table **Contacts**.
4. Modeling > New measure. Copy each measure from PowerBI_DAX_Measures_And_WhatIf.txt **one at a time**. Format percentages as percentages with 1 decimal place.
5. Modeling > New table > `Recovery Rate = GENERATESERIES(0, 1, 0.05)`; do not create a relationship. Add a slicer for Recovery Rate[Value].
6. View > Themes > Browse for themes > PowerBI_Theme.json.
7. Build three report pages following PowerBI_Build_Guide.md and the two PNG layout references.
8. Check key totals above. File > Save As > `.pbix` in Power BI Desktop.

### Notes
- This dataset is generated for demonstration. The scenario effects are hypothetical, not observed business results.
- Do not associate the simulated reporting dates with the dates of actual employment or project completion.
- For public LinkedIn use, share a screenshot or exported PDF *after creating the Power BI report in Desktop*. Do not label the HTML dashboard as Power BI.
