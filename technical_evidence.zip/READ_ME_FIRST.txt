TECHNICAL EVIDENCE - SELF-DIRECTED SYNTHETIC DATA PORTFOLIO
This archive has fictional customer interactions and purposely planted errors.
Files include SQL queries, Python validation, synthetic CSVs, dashboard mart,
requirements / UAT matrix and example DAX measures.
The simulated data covers June 2025 to August 2026.
This does NOT represent employer data or an employer-delivered result.
